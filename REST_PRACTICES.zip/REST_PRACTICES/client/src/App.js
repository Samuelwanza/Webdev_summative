import logo from './logo.svg';
import './App.css';
import Header from './Main/Header'
import Content from './Main/Content'

function App() {
  return (
    <div className="App">
      <Header />
      <Content />
    </div>
  );
}

export default App;
